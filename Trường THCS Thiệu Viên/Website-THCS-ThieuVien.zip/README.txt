
Website tĩnh mẫu cho Trường THCS Thiệu Viên - Thiệu Trung - Thanh Hóa
- Cách dùng:
  1. Giải nén Website-THCS-ThieuVien.zip
  2. Mở file index.html bằng trình duyệt để xem
  3. Để upload lên Netlify: kéo toàn bộ thư mục lên Netlify (app.netlify.com)
- Sửa nội dung: mở các file .html trong thư mục và chỉnh text/ảnh.
- Thêm file tài liệu: đặt trong thư mục assets/files (tạo mới nếu cần).
